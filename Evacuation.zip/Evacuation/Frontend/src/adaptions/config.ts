export const configObject = {
  alpha: 0.9,
  gamma: 0.9,
  epsilon: 0.95
}