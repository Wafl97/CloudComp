import "./EndScreen.scss";

const EndScreen = () => {
  return (
    <div className="end_screen_container">
      <h1>Thank you for your participation!</h1>
    </div>
  );
}

export default EndScreen;